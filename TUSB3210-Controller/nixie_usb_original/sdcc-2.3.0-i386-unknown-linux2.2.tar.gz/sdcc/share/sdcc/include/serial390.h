#ifndef SERIAL390_H
#define SERIAL390_H

#warning "Please use <tinibios.h> instead of <serial390.h>"
#include <tinibios.h>

#endif SERIAL390_H
